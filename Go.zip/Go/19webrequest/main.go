package main

import (
	"fmt"
	"io"
	"net/http"
)

const url = "https://www.google.com"

func main() {

	fmt.Println("welcome to web request in go lang")

	response, err := http.Get(url)
	if err != nil {
		panic(err)
	}
	fmt.Printf("Response is type of %T \n", response)

	// caller's reponsibility to close the connection

	defer response.Body.Close()

	databyte, err := io.ReadAll(response.Body)

	if err != nil {
		fmt.Printf("Failed to read response body: %v\n", err)
		return
	}

	content := string(databyte)

	fmt.Println(content)

}
