package main

import "fmt"

var LogginToken string = "asdzfxcgvhb" //Public

func main() {
	var Username string = "Renuka"
	fmt.Println("Username")
	fmt.Printf("username is  a type of: %T \n", Username)

	var isLoggedIn bool = false
	fmt.Println("isLoggedIn")
	fmt.Printf("varibale is  a type of: %T \n", isLoggedIn)

	var Mobile_Number int = 70002345678
	fmt.Println("Mobile_Number")
	fmt.Printf("mobile number is  a type of: %T \n", Mobile_Number)

	var Small_int uint8 = 255
	fmt.Println("Small_int")
	fmt.Printf("Small int is  a type of: %T \n", Small_int)

	var Small_float float32 = 255.1234567870002345678
	fmt.Println("Small_float")
	fmt.Printf("Small float is  a type of: %T \n", Small_float)

	//defualt Values

	var Anotherint int
	fmt.Println(Anotherint)
	fmt.Printf("Anotherint is  a type of: %T \n", Anotherint)

	var AnotherString string
	fmt.Println(AnotherString)
	fmt.Printf("Another String is  a type of: %T \n", AnotherString)

	//impilcit Type
	var website = "www.google.com"
	fmt.Println(website)

	//no var
	NumOfUser := 34567
	fmt.Println(NumOfUser)

	fmt.Println(LogginToken)
	fmt.Printf("Loggin token is  a type of: %T \n", LogginToken)

}
