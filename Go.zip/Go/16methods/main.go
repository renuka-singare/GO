package main

import "fmt"

func main() {
	fmt.Println("structs in GO lang")

	renuka := User{"Renuka", "renuka234@gmail.com", true, 16}
	fmt.Println(renuka)
	fmt.Printf("renuka details  are : %v\n", renuka)
	fmt.Printf("Name is %v and email is %v", renuka.Name, renuka.Email)
	renuka.Getstatus()
	renuka.NewEmail()
	fmt.Printf("Name is %v and email is %v", renuka.Name, renuka.Email)
}

type User struct {
	Name   string
	Email  string
	Status bool
	Age    int
}

func (u User) Getstatus() {
	fmt.Println("IS user is active", u.Status)

}

func (u User) NewEmail() {
	u.Email = "test@gmail.com"
	fmt.Println("EMail of user is", u.Email)
}
