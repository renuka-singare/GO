package main

import (
	"fmt"
	"time"
)

func main() {
	fmt.Println("Welcome here for learning TIme in go lang")

	PresentTime := time.Now()
	fmt.Println(PresentTime)
	fmt.Println(PresentTime.Format("01-02-2006 15:04:05 Monday"))

	CreatedDate := time.Date(2020, time.August, 12, 12, 45, 23, 00, time.UTC)
	fmt.Println(CreatedDate.Format("01-02-2006 Monday"))
}
