package main

import "fmt"

func main() {
	fmt.Println("maps in golang")

	languages := make(map[string]string)

	languages["PY"] = "python"
	languages["JS"] = "javascript"
	languages["RB"] = "Ruby"

	fmt.Println("List of all languages : ", languages)
	fmt.Println("JS is the short of  : ", languages["JS"])

	delete(languages, "RB")
	fmt.Println(languages)

	for key, value := range languages {
		fmt.Printf("For key  %v , value is %v \n", key, value)
	}

}
