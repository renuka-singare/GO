package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {

	reader := bufio.NewReader(os.Stdin)
	fmt.Println("Enter the rating for our oats")

	//comma ok , comma  err

	input, _ := reader.ReadString('\n')
	fmt.Println("Thanks for shearing rating : ", input)
	fmt.Printf("Type of this rating is : %T ", input)

	//_, err := reader.ReadString('\n')
	//fmt.Println("Thanks for shearing rating : ", input)
	//fmt.Printf("Type of this rating is : ", input)

	//input, err := reader.ReadString('\n')
	//fmt.Println("Thanks for shearing rating : ", input)
	//fmt.Printf("Type of this rating is : ", input)

}
