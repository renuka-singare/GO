package main

import "fmt"

func main() {

	fmt.Println("Welcome here to learn Pointer in go lang")

	// var ptr *int
	// fmt.Println(ptr)

	mypointer := 45
	var ptr = &mypointer
	fmt.Println("the pointer's address is ", ptr)
	fmt.Println("the pointer's value is ", *ptr)

}
