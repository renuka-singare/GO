package main

import "fmt"

func main() {
	fmt.Println("Functions in Go lang")
	greeter()
	result := adder(3, 2)
	fmt.Println("result is : ", result)
	proresult, mymsg := proAdder(1, 2, 3)
	fmt.Println("result is : ", proresult)
	fmt.Println("result is : ", mymsg)
}

func greeter() {
	fmt.Println("Namaste")
}

func adder(val1 int, val2 int) int {
	return val1 + val2
}

//variadic function
func proAdder(values ...int) (int, string) {
	total := 0
	for _, val := range values {
		total += val
	}
	return total, "Renuka"
}
