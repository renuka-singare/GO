package main

import "fmt"

func main() {

	fmt.Println("Welcome here to learn Array ")

	var fruitList [4]string

	fruitList[0] = "Apple"
	fruitList[1] = "banana"
	fruitList[3] = "greps"

	fmt.Println("FruitList is :", fruitList)
	fmt.Println("FruitList Length is :", len(fruitList))

	var vegList = [3]string{"potato", "beanes", "mashroom"}
	fmt.Println("veggy list is:", vegList)
	fmt.Println("veggy list is:", len(vegList))

}
