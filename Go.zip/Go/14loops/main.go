package main

import "fmt"

func main() {
	fmt.Println("Loops in go lang")

	days := []string{"sunday", "monday", "tuesday", "wensday", "thursday", "friday", "saturday"}
	fmt.Println(days)
	// for d := 0; d < len(days); d++ {
	// 	fmt.Println(days[d])
	// }

	//if you will print valu of i
	//fmt.Println(i)
	//this will give you index values

	// for i := range days {
	// 	fmt.Println(days[i])
	// }

	// for _, day := range days {
	// 	fmt.Printf("index is and days is %v \n", day)
	// }

	// for index, day := range days {
	// 	fmt.Printf("index is %v and days is %v \n", index, day)
	// }

	// rougevalue := 1
	// for rougevalue < 10 {
	// 	fmt.Printf("rougevalues value is %v \n", rougevalue)
	// 	rougevalue++
	// }

	rougevalue := 1
	for rougevalue < 10 {
		if rougevalue == 5 {
			//break
			rougevalue++ //this is for continue in case of break use break only
			continue
		}
		fmt.Printf("rougevalues value is %v \n", rougevalue)
		rougevalue++
	}

}
