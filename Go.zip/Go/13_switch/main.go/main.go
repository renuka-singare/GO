package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	fmt.Println("Switch and Cases in Go Lang")

	// Use the current time as the seed for the random number generator
	seed := time.Now().UnixNano()
	randGen := rand.New(rand.NewSource(seed))

	// Generate a random number between 1 and 6 to simulate rolling a six-sided dice
	diceNumber := randGen.Intn(6) + 1 // Adding 1 to include 6 in the possible outcomes
	fmt.Println("Dice number:", diceNumber)

	switch diceNumber {
	case 1:
		fmt.Println("Dice value 1 and you can open")
	case 2:
		fmt.Println("You can move 2 spots")
	case 3:
		fmt.Println("You can move 3 spots")
	case 4:
		fmt.Println("You can move 4 spots")
	case 5:
		fmt.Println("You can move 5 spots")
	case 6:
		fmt.Println("You can move 6 spots, roll the dice again")
	default:
		fmt.Println("What was that")
	}
}
