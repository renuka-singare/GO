package main

import (
	"fmt"
	"sort"
)

func main() {
	fmt.Println("welcome here to learn slices : ")

	var fruitList = []string{"Apple", "Tomato", "Peach"}
	fmt.Printf("Type of fruitlist is %T \n", fruitList)

	fruitList = append(fruitList, "Mango", "Banana")
	fmt.Println(fruitList)

	fruitList = append(fruitList[1:3])
	fmt.Println(fruitList)

	highScore := make([]int, 4)
	highScore[0] = 243
	highScore[1] = 234
	highScore[2] = 765
	highScore[3] = 345

	highScore = append(highScore, 234, 654, 890)
	fmt.Println(highScore)

	fmt.Println(sort.IntsAreSorted(highScore))
	sort.Ints(highScore)
	fmt.Println(highScore)
	fmt.Println(sort.IntsAreSorted(highScore))

	//Super important
	//how to Remove a value from slice based on indexing
	var courses = []string{"java", "python", "swift", "go", "shellscript"}
	fmt.Println(courses)
	var index int = 2
	courses = append(courses[:index], courses[index+1:]...)
	fmt.Println(courses)

}
