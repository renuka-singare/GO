package main

import "fmt"

func main() {

	fmt.Println("Struct in GO lang")

	// there is no inheritance and no super anf parent

	Renuka := User{"Renuka", "Renuka@gmail.com", true, 16}
	//Renuka := User{Name: "Renuka", Email: "Renuka@gmail.com", status: true, Age: 16}

	fmt.Println(Renuka)
	fmt.Printf("Renuka's Details are : %+v\n", Renuka)
	fmt.Printf("Name is %v , Email is %v\n", Renuka.Name, Renuka.Email)
}

type User struct {
	Name   string
	Email  string
	status bool
	Age    int
}
